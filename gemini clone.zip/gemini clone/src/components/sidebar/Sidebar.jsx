import React, { useState } from 'react'
import { icons } from '../../assets/assets';
import './Sidebar.css';



const Sidebar = () => {
    const [extended, setextended] = useState(false)
    return (
        <div className='sidebar'>
            <div className="top">
                <img onClick={()=>setextended(prev=>!prev)} className='menu' src={icons.threeHorizontalLinesIcon} alt="" />
                <div className="newchat">
                    <img src={icons.plusLineIcon} alt="" />
                    {extended ? <p>New chat</p> : null}
                </div>
                {extended ?
                    <div className="recent">
                        <p className='recent-title'>Recent</p>
                        <div className="recent-entry">
                            <img src={icons.chatIcon} alt='' />
                            <p>what is react..</p>
                        </div>
                    </div> : null}

            </div>
            <div className="bottom">
                <div className="bottomitem recent-entry">
                    <img src={icons.questionMarkLineIcon} />
                    {extended?<p>help</p>:null}
                </div>
                <div className="bottomitem recent-entry">
                    <img src={icons.historyLineIcon} />
                    {extended?<p>history</p>:null}
                </div>
                <div className="bottomitem recent-entry">
                    <img src={icons.settingLineIcon} />
                    {extended?<p>settings</p>:null}
                </div>

            </div>

        </div>

    )
}

export default Sidebar
