import React, { useContext } from 'react';
import './Main.css';
import { icons } from '../../assets/assets';
import { Context } from '../../context/Context';

const Main = () => {

  const { onSent, recentprompt, showresult, loading, resultdata, setinput, input } = useContext(Context);

  return (
    <div className="main">
      <div className="nav">
        <p>Gemini</p>
        <img src={icons.nwfl} alt="User Icon" />
      </div>
      <div className="maincontent">

        {!showresult
          ? <>

            <div className="greet">
              <p><span>Hello, Nwfl.</span></p>
              <p>How can I help you today?</p>
            </div>
            <div className="cards">
              <div className="card">
                <p>Suggest hotel rooms near you?</p>
                <img src={icons.idea} alt="Idea Icon" />
              </div>
              <div className="card">
                <p>Brief summary of concept: large language model</p>
                <img src={icons.direc} alt="Direction Icon" />
              </div>
              <div className="card">
                <p>Recent news of Tesla which helps the growth of economy</p>
                <img src={icons.message} alt="Message Icon" />
              </div>
              <div className="card">
                <p>Improve readability of the following code</p>
                <img src={icons.prompt} alt="Prompt Icon" />
              </div>
            </div>


          </>
          : <div className='result'>
            <div className="resulttitle">
              <img src={icons.nwfl} />
              <p>{recentprompt}</p>
            </div>
            <div className="resultdata">
              <img src={icons.gemi} alt="" />
              {loading
                ? <div className='loader'>
                  <hr />
                  <hr />
                  <hr />
                </div>
                : <p dangerouslySetInnerHTML={{ __html: resultdata }}></p>
              }
            </div>

          </div>



        }

        <div className="mainbottom">
          <div className="searchbar">
            <input onChange={(e) => setinput(e.target.value)} value={input} type="text" placeholder="Enter a prompt here" />
            <div>
              <img src={icons.gallery} alt="" />
              <img src={icons.mic} alt="" />
              <img onClick={() => onSent()} src={icons.paperPlaneIcon} alt="" />



            </div>
          </div>
          <p className="bottom-info">
            Gemini may display inaccurate info, including about people, so double-check the response.
          </p>
        </div>
      </div>
    </div>

  );
};

export default Main;
