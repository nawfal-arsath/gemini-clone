// Importing the assets
import chatIcon from './chat.png';
import historyLineIcon from './history.png'; 
import paperPlaneIcon from './paper-plane-icon.png';
import plusLineIcon from './plus-line-icon.png';
import questionMarkLineIcon from './question-mark-line-icon.png';
import settingLineIcon from './setting-line-icon.png';
import threeHorizontalLinesIcon from './three-horizontal-lines-icon.png';
import profiles from './profile.png';
import nwfl from './nwfl.jpg';
import idea from './idea.png';
import message from './message.png';
import prompt from './prompt.png';
import direc from './direc.png';
import mic from './mic.png';
import gemi from './gemi.png';
import gallery from './gallery.png';

// Exporting the assets as an object
export const icons = {
    chatIcon,
    historyLineIcon,
    profiles,
    gemi,
    paperPlaneIcon,
    plusLineIcon,
    questionMarkLineIcon,
    settingLineIcon,
    threeHorizontalLinesIcon,
    nwfl,
    direc,
    message,
    prompt,
    idea,
    mic,
    gallery
  };
