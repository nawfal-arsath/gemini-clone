import { createContext } from "react";
import run from "../config/gemini";
import { useState } from "react";
import { use } from "react";

export const Context = createContext();

const ContextProvider =(props)=>{

const [input,setinput]=useState("");
const [recentprompt,setrecentprompt]=useState("");
const [prevprompt,setprevprompt]=useState([]);
const [showresult,setshowreult]=useState(false);
const [loading,setloading]=useState(false);
const [resultdata,setresultdata]=useState("");

    const onSent=async(prompt)=>{

        setresultdata("")
        setloading(true)
        setshowreult(true)
        await run(input)
        const response =await run(input)
        setresultdata(response)
        setloading(false)
        setinput("")
    }
    
    const ContextValue={
        prevprompt,
        setprevprompt,
        onSent,
        setrecentprompt,
        recentprompt,
        showresult,
        loading,
        resultdata,
        input,
        setinput



    }
    return(
        <Context.Provider value={ContextValue}>
            {props.children}
        </Context.Provider>
    )
}
export default ContextProvider